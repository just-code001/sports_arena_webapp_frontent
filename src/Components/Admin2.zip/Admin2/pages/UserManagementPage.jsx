"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Search, UserPlus, Edit, Trash2, Ban, Check, Plus, Save, Filter } from "lucide-react"
import { useUserStore } from "../store/userStore"
import toast from "react-hot-toast"

const UserManagementPage = () => {
  const {
    users,
    fetchUsers,
    createUser,
    updateUser,
    deleteUser,
    suspendUser,
    activateUser,
    setSearchTerm,
    setStatusFilter,
    setRoleFilter,
    filteredUsers,
    loading,
  } = useUserStore()

  const [isModalOpen, setIsModalOpen] = useState(false)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  const [selectedUser, setSelectedUser] = useState(null)
  const [userToDelete, setUserToDelete] = useState(null)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    role: "owner",
    status: "active",
  })
  const [showFilters, setShowFilters] = useState(false)

  useEffect(() => {
    fetchUsers()
  }, [fetchUsers])

  const openAddModal = () => {
    setSelectedUser(null)
    setFormData({
      name: "",
      email: "",
      role: "owner",
      status: "active",
    })
    setIsModalOpen(true)
  }

  const openEditModal = (user) => {
    console.log("Opening edit modal for user:", user)
    setSelectedUser(user)
    setFormData({
      name: user.name,
      email: user.email,
      role: user.role,
      status: user.status,
    })
    setIsModalOpen(true)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    try {
      if (selectedUser) {
        await updateUser(selectedUser.id, formData)
        toast.success("User updated successfully")
      } else {
        await createUser(formData)
        toast.success("User created successfully")
      }
      setIsModalOpen(false)
    } catch (error) {
      console.error(error)
      toast.error("An error occurred")
    }
  }

  const confirmDelete = (userId) => {
    setUserToDelete(userId)
    setIsDeleteModalOpen(true)
  }

  const handleDelete = async () => {
    if (!userToDelete) return

    try {
      await deleteUser(userToDelete)
      toast.success("User deleted successfully")
      setIsDeleteModalOpen(false)
      setUserToDelete(null)
    } catch (error) {
      console.error(error)
      toast.error("An error occurred")
    }
  }

  const handleSuspend = async (userId) => {
    try {
      await suspendUser(userId)
      toast.success("User suspended")
    } catch (error) {
      console.error(error)
      toast.error("An error occurred")
    }
  }

  const handleActivate = async (userId) => {
    try {
      await activateUser(userId)
      toast.success("User activated")
    } catch (error) {
      console.error(error)
      toast.error("An error occurred")
    }
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSearch = (e) => {
    setSearchTerm(e.target.value)
  }

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="mb-4"
      >
        <h1 className="fs-4 fw-bold">User Management</h1>
        <p className="text-white-50">Manage users and game zone owners</p>
      </motion.div>

      {/* Search and filters */}
      <div className="mb-4">
        <div className="row g-3 align-items-center">
          <div className="col-12 col-md-6">
            <div className="position-relative">
              <Search className="position-absolute start-0 top-50 translate-middle-y ms-3 text-white-50" size={18} />
              <input type="text" placeholder="Search users..." className="form-control ps-5" onChange={handleSearch} />
            </div>
          </div>

          <div className="col-12 col-md-6 d-flex justify-content-md-end gap-2">
            <button
              type="button"
              onClick={() => setShowFilters(!showFilters)}
              className="btn btn-outline-light d-flex align-items-center"
            >
              <Filter size={16} className="me-2" />
              Filters
            </button>

            <button type="button" onClick={openAddModal} className="btn btn-primary d-flex align-items-center">
              <UserPlus size={16} className="me-2" />
              Add User
            </button>
          </div>
        </div>

        {/* Filters */}
        {showFilters && (
          <motion.div
            className="card mt-3"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="card-body">
              <div className="row g-3">
                <div className="col-12 col-md-6">
                  <label className="form-label small fw-medium text-white-50">Status</label>
                  <select className="form-select" onChange={(e) => setStatusFilter(e.target.value)}>
                    <option value="all">All Statuses</option>
                    <option value="active">Active</option>
                    <option value="suspended">Suspended</option>
                  </select>
                </div>

                <div className="col-12 col-md-6">
                  <label className="form-label small fw-medium text-white-50">Role</label>
                  <select className="form-select" onChange={(e) => setRoleFilter(e.target.value)}>
                    <option value="all">All Roles</option>
                    <option value="admin">Admin</option>
                    <option value="moderator">Moderator</option>
                    <option value="owner">Owner</option>
                  </select>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* Users table */}
      <div className="card">
        <div className="table-responsive">
          <table className="table table-dark table-hover mb-0">
            <thead>
              <tr>
                <th>User</th>
                <th>Role</th>
                <th>Status</th>
                <th>Created</th>
                <th>Last Login</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={6} className="text-center py-4">
                    <div className="d-flex justify-content-center">
                      <div className="spinner-border" role="status">
                        <span className="visually-hidden">Loading...</span>
                      </div>
                    </div>
                  </td>
                </tr>
              ) : filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-4">
                    <p className="text-white-50 mb-0">No users found</p>
                  </td>
                </tr>
              ) : (
                filteredUsers.map((user) => (
                  <tr key={user.id}>
                    <td>
                      <div className="d-flex align-items-center">
                        <div
                          className="rounded-circle d-flex align-items-center justify-content-center text-white fw-medium"
                          style={{
                            width: "40px",
                            height: "40px",
                            background: "linear-gradient(to bottom right, var(--primary), var(--secondary))",
                          }}
                        >
                          {user.name.charAt(0)}
                        </div>
                        <div className="ms-3">
                          <p className="fw-medium mb-0">{user.name}</p>
                          <p className="small text-white-50 mb-0">{user.email}</p>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span
                        className={`badge ${
                          user.role === "admin"
                            ? "badge-primary"
                            : user.role === "moderator"
                              ? "badge-secondary"
                              : "badge-info"
                        }`}
                      >
                        {user.role}
                      </span>
                    </td>
                    <td>
                      <span className={`badge ${user.status === "active" ? "badge-success" : "badge-danger"}`}>
                        {user.status}
                      </span>
                    </td>
                    <td>
                      <span className="text-white-50">{new Date(user.createdAt).toLocaleDateString()}</span>
                    </td>
                    <td>
                      <span className="text-white-50">
                        {user.lastLogin ? new Date(user.lastLogin).toLocaleDateString() : "Never"}
                      </span>
                    </td>
                    <td>
                      <div className="d-flex gap-1">
                        <button
                          type="button"
                          className="btn btn-sm btn-outline-secondary"
                          onClick={() => openEditModal(user)}
                        >
                          <Edit size={16} />
                        </button>

                        {user.status === "active" ? (
                          <button
                            type="button"
                            className="btn btn-sm btn-outline-warning"
                            onClick={() => handleSuspend(user.id)}
                          >
                            <Ban size={16} />
                          </button>
                        ) : (
                          <button
                            type="button"
                            className="btn btn-sm btn-outline-success"
                            onClick={() => handleActivate(user.id)}
                          >
                            <Check size={16} />
                          </button>
                        )}

                        <button
                          type="button"
                          className="btn btn-sm btn-outline-danger"
                          onClick={() => confirmDelete(user.id)}
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit User Modal */}
      {isModalOpen && (
        <div className="modal fade show" style={{ display: "block" }} tabIndex="-1" role="dialog" aria-modal="true">
          <div className="modal-dialog modal-dialog-centered">
            <motion.div
              className="modal-content"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
            >
              <div className="modal-header">
                <h5 className="modal-title">{selectedUser ? "Edit User" : "Add New User"}</h5>
                <button
                  type="button"
                  className="btn-close btn-close-white"
                  onClick={() => setIsModalOpen(false)}
                  aria-label="Close"
                ></button>
              </div>
              <div className="modal-body">
                <form onSubmit={handleSubmit} id="userForm">
                  <div className="mb-3">
                    <label htmlFor="name" className="form-label small fw-medium text-white-50">
                      Full Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="form-control"
                      required
                    />
                  </div>

                  <div className="mb-3">
                    <label htmlFor="email" className="form-label small fw-medium text-white-50">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className="form-control"
                      required
                    />
                  </div>

                  <div className="mb-3">
                    <label htmlFor="role" className="form-label small fw-medium text-white-50">
                      Role
                    </label>
                    <select
                      id="role"
                      name="role"
                      value={formData.role}
                      onChange={handleChange}
                      className="form-select"
                      required
                    >
                      <option value="admin">Admin</option>
                      <option value="moderator">Moderator</option>
                      <option value="owner">Owner</option>
                    </select>
                  </div>

                  <div className="mb-3">
                    <label htmlFor="status" className="form-label small fw-medium text-white-50">
                      Status
                    </label>
                    <select
                      id="status"
                      name="status"
                      value={formData.status}
                      onChange={handleChange}
                      className="form-select"
                      required
                    >
                      <option value="active">Active</option>
                      <option value="suspended">Suspended</option>
                    </select>
                  </div>
                </form>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-outline-light" onClick={() => setIsModalOpen(false)}>
                  Cancel
                </button>
                <button type="submit" form="userForm" className="btn btn-primary d-flex align-items-center">
                  {selectedUser ? (
                    <>
                      <Save size={16} className="me-2" />
                      Update User
                    </>
                  ) : (
                    <>
                      <Plus size={16} className="me-2" />
                      Add User
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          </div>
          <div className="modal-backdrop fade show"></div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {isDeleteModalOpen && (
        <div className="modal fade show" style={{ display: "block" }} tabIndex="-1" role="dialog" aria-modal="true">
          <div className="modal-dialog modal-dialog-centered">
            <motion.div
              className="modal-content"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
            >
              <div className="modal-header">
                <h5 className="modal-title text-danger">Confirm Deletion</h5>
                <button
                  type="button"
                  className="btn-close btn-close-white"
                  onClick={() => setIsDeleteModalOpen(false)}
                  aria-label="Close"
                ></button>
              </div>
              <div className="modal-body">
                <p className="text-white-50">Are you sure you want to delete this user?</p>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-outline-light" onClick={() => setIsDeleteModalOpen(false)}>
                  Cancel
                </button>
                <button type="button" className="btn btn-danger d-flex align-items-center" onClick={handleDelete}>
                  <Trash2 size={16} className="me-2" />
                  Delete User
                </button>
              </div>
            </motion.div>
          </div>
          <div className="modal-backdrop fade show"></div>
        </div>
      )}
    </div>
  )
}

export default UserManagementPage
