import { useEffect } from "react"
import { motion } from "framer-motion"
import { Users, GamepadIcon as GameController, ArrowUpRight, Calendar, DollarSign, User } from "lucide-react"
import StatCard from "../components/ui/StatCard"
import AreaChart from "../components/ui/AreaChart"
import { useUserStore } from "../store/userStore"
import { useGameStore } from "../store/gameStore"

const DashboardPage = () => {
  const { fetchUsers, users } = useUserStore()
  const { fetchGames, games } = useGameStore()

  useEffect(() => {
    fetchUsers()
    fetchGames()
  }, [fetchUsers, fetchGames])

  // Mock data for charts
  const userSignupData = [
    { label: "Jan", value: 65 },
    { label: "Feb", value: 59 },
    { label: "Mar", value: 80 },
    { label: "Apr", value: 81 },
    { label: "May", value: 56 },
    { label: "Jun", value: 85 },
    { label: "Jul", value: 90 },
  ]

  const gameUploadsData = [
    { label: "Jan", value: 12 },
    { label: "Feb", value: 19 },
    { label: "Mar", value: 15 },
    { label: "Apr", value: 25 },
    { label: "May", value: 32 },
    { label: "Jun", value: 30 },
    { label: "Jul", value: 38 },
  ]

  const recentGames = games.slice(0, 4)

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="mb-4"
      >
        <h1 className="fs-4 fw-bold">Dashboard</h1>
      </motion.div>

      {/* Stats row */}
      <div className="row g-4 mb-4">
        <div className="col-12 col-md-6 col-lg-3">
          <StatCard title="Total Users" value={users.length} icon={Users} color="primary" percentage={12.5} />
        </div>
        <div className="col-12 col-md-6 col-lg-3">
          <StatCard title="Total Games" value={games.length} icon={GameController} color="secondary" percentage={8.3} />
        </div>
        <div className="col-12 col-md-6 col-lg-3">
          <StatCard title="Revenue" value="$12,543" icon={DollarSign} color="accent" percentage={5.1} />
        </div>
        <div className="col-12 col-md-6 col-lg-3">
          <StatCard title="New Sign Ups" value="24" icon={User} color="success" percentage={-2.4} />
        </div>
      </div>

      {/* Charts row */}
      <div className="row g-4 mb-4">
        <div className="col-12 col-lg-6">
          <AreaChart data={userSignupData} title="User Sign Ups" color="primary" height={240} />
        </div>
        <div className="col-12 col-lg-6">
          <AreaChart data={gameUploadsData} title="Game Uploads" color="secondary" height={240} />
        </div>
      </div>

      {/* Recent uploads and events */}
      <div className="row g-4">
        {/* Recent game uploads */}
        <div className="col-12 col-lg-6">
          <motion.div
            className="card h-100"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.1 }}
          >
            <div className="card-body">
              <div className="d-flex align-items-center justify-content-between mb-3">
                <h5 className="card-title fw-medium mb-0">Recent Game Uploads</h5>
                <button className="btn btn-link text-secondary p-0 small d-flex align-items-center">
                  View all <ArrowUpRight size={14} className="ms-1" />
                </button>
              </div>

              <div className="d-flex flex-column gap-3">
                {recentGames.map((game) => (
                  <div key={game.id} className="d-flex align-items-center p-2 rounded bg-dark bg-opacity-50">
                    <div className="rounded overflow-hidden flex-shrink-0" style={{ width: "48px", height: "48px" }}>
                      <img
                        src={game.thumbnail || "/placeholder.svg"}
                        alt={game.title}
                        className="w-100 h-100 object-fit-cover"
                      />
                    </div>
                    <div className="ms-3 flex-grow-1">
                      <h6 className="fw-medium text-white mb-0">{game.title}</h6>
                      <p className="small text-white-50 mb-0">By {game.ownerName}</p>
                    </div>
                    <div className="ms-auto">
                      <span
                        className={`badge ${
                          game.status === "approved"
                            ? "badge-success"
                            : game.status === "rejected"
                              ? "badge-danger"
                              : "badge-warning"
                        }`}
                      >
                        {game.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>

        {/* Upcoming events */}
        <div className="col-12 col-lg-6">
          <motion.div
            className="card h-100"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.2 }}
          >
            <div className="card-body">
              <div className="d-flex align-items-center justify-content-between mb-3">
                <h5 className="card-title fw-medium mb-0">Upcoming Events</h5>
                <button className="btn btn-link text-secondary p-0 small d-flex align-items-center">
                  View all <ArrowUpRight size={14} className="ms-1" />
                </button>
              </div>

              <div className="d-flex flex-column gap-3">
                <div className="p-2 rounded bg-dark bg-opacity-50">
                  <div className="d-flex align-items-center">
                    <div
                      className="rounded-circle d-flex align-items-center justify-content-center"
                      style={{ width: "40px", height: "40px", backgroundColor: "rgba(255, 42, 109, 0.2)" }}
                    >
                      <Calendar size={18} style={{ color: "var(--primary)" }} />
                    </div>
                    <div className="ms-3">
                      <h6 className="fw-medium text-white mb-0">Subscription Price Update</h6>
                      <p className="small text-white-50 mb-0">Tomorrow, 10:00 AM</p>
                    </div>
                  </div>
                </div>

                <div className="p-2 rounded bg-dark bg-opacity-50">
                  <div className="d-flex align-items-center">
                    <div
                      className="rounded-circle d-flex align-items-center justify-content-center"
                      style={{ width: "40px", height: "40px", backgroundColor: "rgba(5, 217, 232, 0.2)" }}
                    >
                      <Calendar size={18} style={{ color: "var(--secondary)" }} />
                    </div>
                    <div className="ms-3">
                      <h6 className="fw-medium text-white mb-0">Game Developer Conference</h6>
                      <p className="small text-white-50 mb-0">July 15, 9:00 AM</p>
                    </div>
                  </div>
                </div>

                <div className="p-2 rounded bg-dark bg-opacity-50">
                  <div className="d-flex align-items-center">
                    <div
                      className="rounded-circle d-flex align-items-center justify-content-center"
                      style={{ width: "40px", height: "40px", backgroundColor: "rgba(255, 215, 0, 0.2)" }}
                    >
                      <Calendar size={18} style={{ color: "var(--accent)" }} />
                    </div>
                    <div className="ms-3">
                      <h6 className="fw-medium text-white mb-0">Platform Maintenance</h6>
                      <p className="small text-white-50 mb-0">July 20, 2:00 AM</p>
                    </div>
                  </div>
                </div>

                <div className="p-2 rounded bg-dark bg-opacity-50">
                  <div className="d-flex align-items-center">
                    <div
                      className="rounded-circle d-flex align-items-center justify-content-center"
                      style={{ width: "40px", height: "40px", backgroundColor: "rgba(40, 167, 69, 0.2)" }}
                    >
                      <Calendar size={18} style={{ color: "#4cd964" }} />
                    </div>
                    <div className="ms-3">
                      <h6 className="fw-medium text-white mb-0">Summer Gaming Festival</h6>
                      <p className="small text-white-50 mb-0">August 5, 11:00 AM</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  )
}

export default DashboardPage
