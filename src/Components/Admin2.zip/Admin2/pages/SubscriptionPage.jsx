"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Search, Plus, Edit, Trash2, X, Save, Check, Filter, ToggleLeft, ToggleRight } from "lucide-react"
import { useSubscriptionStore } from "../store/subscriptionStore"
import toast from "react-hot-toast"

const SubscriptionPage = () => {
  const {
    plans,
    fetchPlans,
    createPlan,
    updatePlan,
    deletePlan,
    togglePlanStatus,
    setSearchTerm,
    setUserTypeFilter,
    setBillingCycleFilter,
    filteredPlans,
    loading,
  } = useSubscriptionStore()

  const [isModalOpen, setIsModalOpen] = useState(false)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState(null)
  const [planToDelete, setPlanToDelete] = useState(null)
  const [formData, setFormData] = useState({
    name: "",
    price: 0,
    billingCycle: "monthly",
    features: [""],
    userType: "user",
    isActive: true,
  })
  const [showFilters, setShowFilters] = useState(false)

  useEffect(() => {
    fetchPlans()
  }, [fetchPlans])

  const openAddModal = () => {
    setSelectedPlan(null)
    setFormData({
      name: "",
      price: 0,
      billingCycle: "monthly",
      features: [""],
      userType: "user",
      isActive: true,
    })
    setIsModalOpen(true)
  }

  const openEditModal = (plan) => {
    setSelectedPlan(plan)
    setFormData({
      name: plan.name,
      price: plan.price,
      billingCycle: plan.billingCycle,
      features: [...plan.features],
      userType: plan.userType,
      isActive: plan.isActive,
    })
    setIsModalOpen(true)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      if (selectedPlan) {
        await updatePlan(selectedPlan.id, formData)
        toast.success("Subscription plan updated successfully")
      } else {
        await createPlan(formData)
        toast.success("Subscription plan created successfully")
      }
      setIsModalOpen(false)
    } catch (error) {
      console.error(error)
      toast.error("An error occurred")
    }
  }

  const confirmDelete = (planId) => {
    setPlanToDelete(planId)
    setIsDeleteModalOpen(true)
  }

  const handleDelete = async () => {
    if (!planToDelete) return
    try {
      await deletePlan(planToDelete)
      toast.success("Subscription plan deleted successfully")
      setIsDeleteModalOpen(false)
      setPlanToDelete(null)
    } catch (error) {
      console.error(error)
      toast.error("An error occurred")
    }
  }

  const handleToggleStatus = async (planId) => {
    try {
      await togglePlanStatus(planId)
      toast.success("Plan status updated")
    } catch (error) {
      console.error(error)
      toast.error("An error occurred")
    }
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    if (name === "price") {
      setFormData((prev) => ({ ...prev, [name]: Number.parseFloat(value) }))
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }))
    }
  }

  const handleFeatureChange = (index, value) => {
    const updatedFeatures = [...formData.features]
    updatedFeatures[index] = value
    setFormData((prev) => ({ ...prev, features: updatedFeatures }))
  }

  const addFeature = () => {
    setFormData((prev) => ({ ...prev, features: [...prev.features, ""] }))
  }

  const removeFeature = (index) => {
    const updatedFeatures = [...formData.features]
    updatedFeatures.splice(index, 1)
    setFormData((prev) => ({ ...prev, features: updatedFeatures }))
  }

  const handleSearch = (e) => {
    setSearchTerm(e.target.value)
  }

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="mb-4"
      >
        <h1 className="fs-4 fw-bold">Subscription Plans</h1>
        <p className="text-white-50">Manage subscription plans for users and game zone owners</p>
      </motion.div>

      {/* Search and filters */}
      <div className="mb-4">
        <div className="row g-3 align-items-center">
          <div className="col-12 col-md-6">
            <div className="position-relative">
              <Search className="position-absolute start-0 top-50 translate-middle-y ms-3 text-white-50" size={18} />
              <input type="text" placeholder="Search plans..." className="form-control ps-5" onChange={handleSearch} />
            </div>
          </div>

          <div className="col-12 col-md-6 d-flex justify-content-md-end gap-2">
            <button
              type="button"
              onClick={() => setShowFilters(!showFilters)}
              className="btn btn-outline-light d-flex align-items-center"
            >
              <Filter size={16} className="me-2" />
              Filters
            </button>

            <button type="button" onClick={openAddModal} className="btn btn-primary d-flex align-items-center">
              <Plus size={16} className="me-2" />
              Add Plan
            </button>
          </div>
        </div>

        {/* Filters */}
        {showFilters && (
          <motion.div
            className="card mt-3"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="card-body">
              <div className="row g-3">
                <div className="col-12 col-md-6">
                  <label className="form-label small fw-medium text-white-50">User Type</label>
                  <select className="form-select" onChange={(e) => setUserTypeFilter(e.target.value)}>
                    <option value="all">All User Types</option>
                    <option value="user">User</option>
                    <option value="owner">Owner</option>
                    <option value="both">Both</option>
                  </select>
                </div>

                <div className="col-12 col-md-6">
                  <label className="form-label small fw-medium text-white-50">Billing Cycle</label>
                  <select className="form-select" onChange={(e) => setBillingCycleFilter(e.target.value)}>
                    <option value="all">All Billing Cycles</option>
                    <option value="monthly">Monthly</option>
                    <option value="yearly">Yearly</option>
                  </select>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* Subscription plans cards */}
      <div className="row g-4">
        {loading ? (
          <div className="col-12 d-flex justify-content-center py-5">
            <div className="spinner-border" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        ) : filteredPlans.length === 0 ? (
          <div className="col-12 text-center py-5">
            <p className="text-white-50">No subscription plans found</p>
          </div>
        ) : (
          filteredPlans.map((plan) => (
            <div key={plan.id} className="col-12 col-md-6 col-lg-4">
              <motion.div
                className="card h-100"
                style={{
                  borderColor: plan.isActive ? "rgba(255, 255, 255, 0.1)" : "rgba(220, 53, 69, 0.3)",
                  opacity: plan.isActive ? 1 : 0.7,
                }}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: plan.isActive ? 1 : 0.7, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-center mb-3">
                    <h5 className="card-title fw-bold mb-0">{plan.name}</h5>
                    <div className="d-flex gap-1">
                      <span className={`badge ${plan.isActive ? "badge-success" : "badge-danger"}`}>
                        {plan.isActive ? "Active" : "Inactive"}
                      </span>
                      <span
                        className={`badge ${
                          plan.userType === "user"
                            ? "badge-primary"
                            : plan.userType === "owner"
                              ? "badge-secondary"
                              : "badge-accent"
                        }`}
                      >
                        {plan.userType === "user" ? "User" : plan.userType === "owner" ? "Owner" : "Both"}
                      </span>
                    </div>
                  </div>

                  <div className="mb-3">
                    <span className="fs-3 fw-bold">${plan.price}</span>
                    <span className="text-white-50 ms-1">/{plan.billingCycle}</span>
                  </div>

                  <ul className="list-unstyled mb-4">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="d-flex mb-2">
                        <Check size={16} className="text-success me-2 flex-shrink-0 mt-1" />
                        <span className="text-white-50">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="d-flex justify-content-between align-items-center">
                    <button type="button" onClick={() => handleToggleStatus(plan.id)} className="btn btn-link p-0">
                      {plan.isActive ? (
                        <ToggleRight size={20} className="text-success" />
                      ) : (
                        <ToggleLeft size={20} className="text-danger" />
                      )}
                    </button>

                    <div className="d-flex gap-1">
                      <button
                        type="button"
                        onClick={() => openEditModal(plan)}
                        className="btn btn-sm btn-link text-secondary"
                      >
                        <Edit size={16} />
                      </button>

                      <button
                        type="button"
                        onClick={() => confirmDelete(plan.id)}
                        className="btn btn-sm btn-link text-danger"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          ))
        )}
      </div>

      {/* Add/Edit Plan Modal */}
      {isModalOpen && (
        <div className="modal fade show" style={{ display: "block" }} tabIndex="-1">
          <div className="modal-dialog modal-dialog-centered modal-lg">
            <motion.div
              className="modal-content"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
            >
              <div className="modal-header">
                <h5 className="modal-title">{selectedPlan ? "Edit Subscription Plan" : "Add New Subscription Plan"}</h5>
                <button
                  type="button"
                  className="btn-close btn-close-white"
                  onClick={() => setIsModalOpen(false)}
                ></button>
              </div>
              <div className="modal-body">
                <form onSubmit={handleSubmit}>
                  <div className="row g-3 mb-3">
                    <div className="col-12 col-md-6">
                      <label htmlFor="name" className="form-label small fw-medium text-white-50">
                        Plan Name
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        className="form-control"
                        required
                      />
                    </div>

                    <div className="col-12 col-md-6">
                      <label htmlFor="price" className="form-label small fw-medium text-white-50">
                        Price
                      </label>
                      <input
                        type="number"
                        id="price"
                        name="price"
                        step="0.01"
                        value={formData.price}
                        onChange={handleChange}
                        className="form-control"
                        required
                      />
                    </div>
                  </div>

                  <div className="row g-3 mb-4">
                    <div className="col-12 col-md-6">
                      <label htmlFor="billingCycle" className="form-label small fw-medium text-white-50">
                        Billing Cycle
                      </label>
                      <select
                        id="billingCycle"
                        name="billingCycle"
                        value={formData.billingCycle}
                        onChange={handleChange}
                        className="form-select"
                        required
                      >
                        <option value="monthly">Monthly</option>
                        <option value="yearly">Yearly</option>
                      </select>
                    </div>

                    <div className="col-12 col-md-6">
                      <label htmlFor="userType" className="form-label small fw-medium text-white-50">
                        User Type
                      </label>
                      <select
                        id="userType"
                        name="userType"
                        value={formData.userType}
                        onChange={handleChange}
                        className="form-select"
                        required
                      >
                        <option value="user">User</option>
                        <option value="owner">Owner</option>
                        <option value="both">Both</option>
                      </select>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <label className="form-label small fw-medium text-white-50 mb-0">Features</label>
                      <button
                        type="button"
                        onClick={addFeature}
                        className="btn btn-link text-secondary p-0 small d-flex align-items-center"
                      >
                        <Plus size={14} className="me-1" />
                        Add Feature
                      </button>
                    </div>

                    {formData.features.map((feature, index) => (
                      <div key={index} className="d-flex align-items-center mb-2">
                        <input
                          type="text"
                          value={feature}
                          onChange={(e) => handleFeatureChange(index, e.target.value)}
                          className="form-control me-2"
                          placeholder="Feature description"
                          required
                        />
                        {formData.features.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeFeature(index)}
                            className="btn btn-link text-danger p-0"
                          >
                            <X size={16} />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>

                  <div className="d-flex justify-content-end gap-2">
                    <button type="button" onClick={() => setIsModalOpen(false)} className="btn btn-outline-light">
                      Cancel
                    </button>
                    <button type="submit" className="btn btn-primary d-flex align-items-center">
                      <Save size={16} className="me-2" />
                      {selectedPlan ? "Update Plan" : "Create Plan"}
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
          <div className="modal-backdrop fade show"></div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {isDeleteModalOpen && (
        <div className="modal fade show" style={{ display: "block" }} tabIndex="-1">
          <div className="modal-dialog modal-dialog-centered">
            <motion.div
              className="modal-content"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
            >
              <div className="modal-header">
                <h5 className="modal-title text-danger">Confirm Deletion</h5>
                <button
                  type="button"
                  className="btn-close btn-close-white"
                  onClick={() => setIsDeleteModalOpen(false)}
                ></button>
              </div>
              <div className="modal-body">
                <p>Are you sure you want to delete this subscription plan? This action cannot be undone.</p>
              </div>
              <div className="modal-footer">
                <button type="button" onClick={() => setIsDeleteModalOpen(false)} className="btn btn-outline-light">
                  Cancel
                </button>
                <button type="button" onClick={handleDelete} className="btn btn-danger">
                  Delete Plan
                </button>
              </div>
            </motion.div>
          </div>
          <div className="modal-backdrop fade show"></div>
        </div>
      )}
    </div>
  )
}

export default SubscriptionPage
