"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Search, Filter, ThumbsUp, ThumbsDown, Eye, X } from "lucide-react"
import { useGameStore } from "../store/gameStore"
import { useAuthStore } from "../store/authStore"
import toast from "react-hot-toast"

const GameManagementPage = () => {
  const {
    games,
    fetchGames,
    approveGame,
    rejectGame,
    setSearchTerm,
    setStatusFilter,
    setGenreFilter,
    filteredGames,
    loading,
  } = useGameStore()

  const { user } = useAuthStore()

  const [showFilters, setShowFilters] = useState(false)
  const [viewGame, setViewGame] = useState(null)

  useEffect(() => {
    fetchGames()
  }, [fetchGames])

  const handleApprove = async (gameId) => {
    if (!user) return

    try {
      await approveGame(gameId, user.id, user.name)
      toast.success("Game approved successfully")
    } catch (error) {
      console.error(error)
      toast.error("An error occurred")
    }
  }

  const handleReject = async (gameId) => {
    if (!user) return

    try {
      await rejectGame(gameId, user.id, user.name)
      toast.success("Game rejected")
    } catch (error) {
      console.error(error)
      toast.error("An error occurred")
    }
  }

  const handleSearch = (e) => {
    setSearchTerm(e.target.value)
  }

  const getStatusColor = (status) => {
    switch (status) {
      case "approved":
        return "badge-success"
      case "rejected":
        return "badge-danger"
      default:
        return "badge-warning"
    }
  }

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="mb-4"
      >
        <h1 className="fs-4 fw-bold">Game Management</h1>
        <p className="text-white-50">Review and manage games uploaded by game zone owners</p>
      </motion.div>

      {/* Search and filters */}
      <div className="mb-4">
        <div className="row g-3 align-items-center">
          <div className="col-12 col-md-6">
            <div className="position-relative">
              <Search className="position-absolute start-0 top-50 translate-middle-y ms-3 text-white-50" size={18} />
              <input type="text" placeholder="Search games..." className="form-control ps-5" onChange={handleSearch} />
            </div>
          </div>

          <div className="col-12 col-md-6 d-flex justify-content-md-end">
            <button
              type="button"
              onClick={() => setShowFilters(!showFilters)}
              className="btn btn-outline-light d-flex align-items-center"
            >
              <Filter size={16} className="me-2" />
              Filters
            </button>
          </div>
        </div>

        {/* Filters */}
        {showFilters && (
          <motion.div
            className="card mt-3"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="card-body">
              <div className="row g-3">
                <div className="col-12 col-md-6">
                  <label className="form-label small fw-medium text-white-50">Status</label>
                  <select className="form-select" onChange={(e) => setStatusFilter(e.target.value)}>
                    <option value="all">All Statuses</option>
                    <option value="pending">Pending</option>
                    <option value="approved">Approved</option>
                    <option value="rejected">Rejected</option>
                  </select>
                </div>

                <div className="col-12 col-md-6">
                  <label className="form-label small fw-medium text-white-50">Genre</label>
                  <select className="form-select" onChange={(e) => setGenreFilter(e.target.value)}>
                    <option value="all">All Genres</option>
                    <option value="Racing">Racing</option>
                    <option value="Strategy">Strategy</option>
                    <option value="Adventure">Adventure</option>
                    <option value="RPG">RPG</option>
                  </select>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* Games grid */}
      <div className="row g-4">
        {loading ? (
          <div className="col-12 d-flex justify-content-center py-5">
            <div className="spinner-border" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        ) : filteredGames.length === 0 ? (
          <div className="col-12 text-center py-5">
            <p className="text-white-50">No games found</p>
          </div>
        ) : (
          filteredGames.map((game) => (
            <div key={game.id} className="col-12 col-md-6 col-lg-4">
              <motion.div
                className="card h-100"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                style={{
                  borderColor: game.status === "active" ? "rgba(255, 255, 255, 0.1)" : "rgba(220, 53, 69, 0.3)",
                }}
              >
                <div className="position-relative" style={{ height: "160px" }}>
                  <img
                    src={game.thumbnail || "/placeholder.svg"}
                    alt={game.title}
                    className="w-100 h-100 object-fit-cover"
                  />
                  <div className="position-absolute top-0 end-0 m-2">
                    <span className={`badge ${getStatusColor(game.status)}`}>{game.status}</span>
                  </div>
                </div>
                <div className="card-body">
                  <h5 className="card-title fw-bold">{game.title}</h5>
                  <p className="small text-white-50 mb-2">By {game.ownerName}</p>
                  <p className="small text-white-50 mb-3 text-truncate">{game.description}</p>

                  <div className="d-flex justify-content-between align-items-center">
                    <div className="small text-white-50">
                      <span className="d-block">Genre: {game.genre}</span>
                      <span>Submitted: {new Date(game.submittedAt).toLocaleDateString()}</span>
                    </div>

                    <div className="d-flex gap-1">
                      <button
                        type="button"
                        onClick={() => setViewGame(game)}
                        className="btn btn-sm btn-link text-white"
                      >
                        <Eye size={18} />
                      </button>

                      {game.status === "pending" && (
                        <>
                          <button
                            type="button"
                            onClick={() => handleApprove(game.id)}
                            className="btn btn-sm btn-link text-success"
                          >
                            <ThumbsUp size={18} />
                          </button>

                          <button
                            type="button"
                            onClick={() => handleReject(game.id)}
                            className="btn btn-sm btn-link text-danger"
                          >
                            <ThumbsDown size={18} />
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          ))
        )}
      </div>

      {/* Game Detail Modal */}
      {viewGame && (
        <div className="modal fade show" style={{ display: "block" }} tabIndex="-1">
          <div className="modal-dialog modal-dialog-centered modal-lg">
            <motion.div
              className="modal-content"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
            >
              <div className="position-relative" style={{ height: "240px" }}>
                <img
                  src={viewGame.thumbnail || "/placeholder.svg"}
                  alt={viewGame.title}
                  className="w-100 h-100 object-fit-cover"
                />
                <button
                  type="button"
                  onClick={() => setViewGame(null)}
                  className="btn btn-dark position-absolute top-0 end-0 m-3 rounded-circle p-1"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="modal-body">
                <div className="d-flex justify-content-between align-items-center mb-4">
                  <h4 className="fw-bold">{viewGame.title}</h4>
                  <span className={`badge ${getStatusColor(viewGame.status)}`}>{viewGame.status}</span>
                </div>

                <div className="row g-4 mb-4">
                  <div className="col-12 col-md-6">
                    <h5 className="fw-medium mb-3">Details</h5>
                    <div className="small">
                      <p className="mb-2">
                        <span className="text-white-50">Genre:</span> {viewGame.genre}
                      </p>
                      <p className="mb-2">
                        <span className="text-white-50">Submitted by:</span> {viewGame.ownerName}
                      </p>
                      <p className="mb-2">
                        <span className="text-white-50">Submitted on:</span>{" "}
                        {new Date(viewGame.submittedAt).toLocaleString()}
                      </p>

                      {viewGame.reviewedAt && (
                        <>
                          <p className="mb-2">
                            <span className="text-white-50">Reviewed on:</span>{" "}
                            {new Date(viewGame.reviewedAt).toLocaleString()}
                          </p>
                          <p className="mb-0">
                            <span className="text-white-50">Reviewed by:</span> {viewGame.reviewedBy}
                          </p>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="col-12 col-md-6">
                    <h5 className="fw-medium mb-3">Description</h5>
                    <p className="text-white-50">{viewGame.description}</p>
                  </div>
                </div>

                {viewGame.status === "pending" && (
                  <div className="d-flex justify-content-end gap-2 border-top border-secondary-subtle pt-3">
                    <button
                      type="button"
                      onClick={() => {
                        handleReject(viewGame.id)
                        setViewGame(null)
                      }}
                      className="btn btn-danger d-flex align-items-center"
                    >
                      <ThumbsDown size={16} className="me-2" />
                      Reject Game
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        handleApprove(viewGame.id)
                        setViewGame(null)
                      }}
                      className="btn btn-success d-flex align-items-center"
                    >
                      <ThumbsUp size={16} className="me-2" />
                      Approve Game
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
          <div className="modal-backdrop fade show"></div>
        </div>
      )}
    </div>
  )
}

export default GameManagementPage
