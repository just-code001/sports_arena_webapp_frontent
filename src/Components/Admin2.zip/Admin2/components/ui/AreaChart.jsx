"use client"
import { motion } from "framer-motion"

const AreaChart = ({ data, title, color = "primary", height = 200 }) => {
  if (!data || data.length === 0) return null

  const maxValue = Math.max(...data.map((d) => d.value))
  const totalPoints = data.length

  const getColor = () => {
    switch (color) {
      case "primary":
        return {
          stroke: "rgb(255, 42, 109)",
          fill: "rgba(255, 42, 109, 0.1)",
        }
      case "secondary":
        return {
          stroke: "rgb(5, 217, 232)",
          fill: "rgba(5, 217, 232, 0.1)",
        }
      case "accent":
        return {
          stroke: "rgb(255, 215, 0)",
          fill: "rgba(255, 215, 0, 0.1)",
        }
      default:
        return {
          stroke: "rgb(255, 42, 109)",
          fill: "rgba(255, 42, 109, 0.1)",
        }
    }
  }

  const chartColors = getColor()

  const getPathData = () => {
    const points = data.map((dataPoint, index) => {
      const x = (index / (totalPoints - 1)) * 100
      const y = 100 - (dataPoint.value / maxValue) * 95
      return `${x},${y}`
    })

    return `M0,100 L${points.join(" L")} L100,100 Z`
  }

  const getLineData = () => {
    const points = data.map((dataPoint, index) => {
      const x = (index / (totalPoints - 1)) * 100
      const y = 100 - (dataPoint.value / maxValue) * 95
      return `${x},${y}`
    })

    return `M${points.join(" L")}`
  }

  return (
    <div className="card h-100">
      <div className="card-body">
        <h5 className="card-title text-white fw-medium mb-3">{title}</h5>
        <div style={{ height: `${height}px`, position: "relative" }}>
          <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
            {/* Grid lines */}
            <line x1="0" y1="0" x2="100" y2="0" stroke="rgba(255,255,255,0.1)" strokeWidth="0.5" />
            <line x1="0" y1="25" x2="100" y2="25" stroke="rgba(255,255,255,0.1)" strokeWidth="0.5" />
            <line x1="0" y1="50" x2="100" y2="50" stroke="rgba(255,255,255,0.1)" strokeWidth="0.5" />
            <line x1="0" y1="75" x2="100" y2="75" stroke="rgba(255,255,255,0.1)" strokeWidth="0.5" />
            <line x1="0" y1="100" x2="100" y2="100" stroke="rgba(255,255,255,0.1)" strokeWidth="0.5" />

            {/* Area */}
            <motion.path
              d={getPathData()}
              fill={chartColors.fill}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.2 }}
            />

            {/* Line */}
            <motion.path
              d={getLineData()}
              fill="none"
              stroke={chartColors.stroke}
              strokeWidth="2"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 1.5, ease: "easeInOut" }}
            />

            {/* Data points */}
            {data.map((dataPoint, index) => {
              const x = (index / (totalPoints - 1)) * 100
              const y = 100 - (dataPoint.value / maxValue) * 95

              return (
                <motion.circle
                  key={index}
                  cx={x}
                  cy={y}
                  r="1.5"
                  fill={chartColors.stroke}
                  initial={{ opacity: 0, scale: 0 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.3, delay: 0.8 + index * 0.05 }}
                />
              )
            })}
          </svg>
        </div>

        {/* X-axis labels */}
        <div className="d-flex justify-content-between mt-2 small text-white-50">
          {data
            .filter((_, i) => i % Math.ceil(data.length / 5) === 0 || i === data.length - 1)
            .map((dataPoint, index) => (
              <div key={index}>{dataPoint.label}</div>
            ))}
        </div>
      </div>
    </div>
  )
}

export default AreaChart
