"use client"
import { motion } from "framer-motion"

const StatCard = ({ title, value, icon: Icon, color, percentage }) => {
  const getColorClasses = () => {
    switch (color) {
      case "primary":
        return {
          bg: "rgba(255, 42, 109, 0.1)",
          text: "var(--primary)",
          border: "rgba(255, 42, 109, 0.3)",
        }
      case "secondary":
        return {
          bg: "rgba(5, 217, 232, 0.1)",
          text: "var(--secondary)",
          border: "rgba(5, 217, 232, 0.3)",
        }
      case "accent":
        return {
          bg: "rgba(255, 215, 0, 0.1)",
          text: "var(--accent)",
          border: "rgba(255, 215, 0, 0.3)",
        }
      case "success":
        return {
          bg: "rgba(40, 167, 69, 0.1)",
          text: "#4cd964",
          border: "rgba(40, 167, 69, 0.3)",
        }
      case "warning":
        return {
          bg: "rgba(255, 193, 7, 0.1)",
          text: "#ffcc00",
          border: "rgba(255, 193, 7, 0.3)",
        }
      default:
        return {
          bg: "rgba(255, 42, 109, 0.1)",
          text: "var(--primary)",
          border: "rgba(255, 42, 109, 0.3)",
        }
    }
  }

  const colors = getColorClasses()

  return (
    <motion.div
      className="card h-100"
      style={{ borderColor: colors.border }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="card-body d-flex align-items-center justify-content-between">
        <div>
          <h6 className="text-white-50 small mb-1">{title}</h6>
          <p className="fs-4 fw-bold mb-1">{value}</p>

          {percentage !== undefined && (
            <div className="d-flex align-items-center small">
              <span style={{ color: percentage >= 0 ? "#4cd964" : "#ff3b30" }}>
                {percentage >= 0 ? "+" : ""}
                {percentage}%
              </span>
              <span className="ms-1 text-white-50">vs last month</span>
            </div>
          )}
        </div>
        <div className="rounded p-2" style={{ backgroundColor: colors.bg, color: colors.text }}>
          <Icon size={24} />
        </div>
      </div>
    </motion.div>
  )
}

export default StatCard
