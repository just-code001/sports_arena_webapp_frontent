import React from "react";
import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  Users,
  Gamepad,
  CreditCard,
  Settings,
  ShieldCheck,
} from "lucide-react";

const Sidebar = ({ isOpen, closeSidebar }) => {
  const items = [
    { title: "Dashboard", icon: <LayoutDashboard size={20} />, path: "/admin2/dashboard" },
    { title: "User Management", icon: <Users size={20} />, path: "/admin2/users" },
    { title: "Game Management", icon: <Gamepad size={20} />, path: "/admin2/games" },
    { title: "Subscription Plans", icon: <CreditCard size={20} />, path: "/admin2/subscriptions" },
    { title: "Permissions", icon: <ShieldCheck size={20} />, path: "/admin2/permissions" },
    { title: "Settings", icon: <Settings size={20} />, path: "/admin2/settings" },
  ];

  return (
    <>
      {/* Overlay for mobile */}
      {window.innerWidth < 992 && isOpen && (
        <div
          className="position-fixed top-0 start-0 w-100 h-100 bg-dark bg-opacity-50"
          style={{ zIndex: 1040 }}
          onClick={closeSidebar}
        ></div>
      )}

      <div
        className={`bg-dark text-white position-fixed top-0 start-0 h-100 d-flex flex-column ${
          isOpen ? "d-block" : "d-none d-lg-block"
        }`}
        style={{ width: "16rem", zIndex: 1045 }}
      >
        <div className="border-bottom border-secondary-subtle p-3">
          <h1 className="fs-4 fw-bold mb-0">
            <span style={{ color: "var(--primary)" }}>Game</span>
            <span style={{ color: "var(--accent)" }}>Zone</span>
          </h1>
        </div>

        <div className="flex-grow-1 overflow-auto">
          {items.map((item, idx) => (
            <NavLink
              key={idx}
              to={item.path}
              className={({ isActive }) =>
                `d-flex align-items-center text-white px-3 py-2 text-decoration-none ${
                  isActive ? "bg-primary" : "hover-bg-dark"
                }`
              }
              onClick={closeSidebar}
            >
              {item.icon}
              <span className="ms-2">{item.title}</span>
            </NavLink>
          ))}
        </div>
      </div>
    </>
  );
};

export default Sidebar;
