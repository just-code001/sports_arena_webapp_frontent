import React, { useState } from "react"
import { Bell, User, LogOut, Menu } from "lucide-react"
import { useAuthStore } from "../../store/authStore"

const Header = ({ toggleSidebar }) => {
  const { user, logout } = useAuthStore()
  const [showProfileMenu, setShowProfileMenu] = useState(false)
  const [showNotifications, setShowNotifications] = useState(false)

  const toggleProfileMenu = () => {
    setShowProfileMenu(!showProfileMenu)
    if (showNotifications) setShowNotifications(false)
  }

  const toggleNotifications = () => {
    setShowNotifications(!showNotifications)
    if (showProfileMenu) setShowProfileMenu(false)
  }

  const handleLogout = () => logout()

  return (
    <header className="bg-dark sticky-top border-bottom border-secondary-subtle">
      <div className="d-flex align-items-center justify-content-between px-3 py-2">
        {/* Left - Logo & Toggle */}
        <div className="d-flex align-items-center">
          <button onClick={toggleSidebar} className="btn btn-link d-lg-none text-white me-2 p-1">
            <Menu size={24} />
          </button>
          <h1 className="fs-4 fw-bold text-white m-0 d-flex align-items-center">
            <span style={{ color: "var(--primary)" }}>Game</span>
            <span style={{ color: "var(--accent)" }}>Zone</span>
            <span style={{ color: "var(--secondary)" }} className="ms-1">Admin</span>
          </h1>
        </div>

        {/* Right - Notification & Profile */}
        <div className="d-flex align-items-center">
          {/* Notification bell */}
          <div className="position-relative me-3">
            <button onClick={toggleNotifications} className="btn btn-link text-white p-1">
              <Bell size={20} />
              <span className="position-absolute top-0 end-0 translate-middle bg-primary rounded-circle" style={{ width: "8px", height: "8px" }}></span>
            </button>

            {showNotifications && (
              <div className="position-absolute end-0 mt-2 dropdown-menu show fadeIn" style={{ width: "18rem" }}>
                <div className="d-flex justify-content-between align-items-center px-3 py-2 border-bottom">
                  <h6 className="fw-medium text-white mb-0">Notifications</h6>
                  <span className="badge bg-primary bg-opacity-25 text-primary rounded-pill">3 new</span>
                </div>
                <div style={{ maxHeight: "24rem", overflowY: "auto" }}>
                  <div className="dropdown-item text-white border-bottom">
                    <p className="mb-1">New game submission from <span className="fw-medium">NeonGames Inc.</span></p>
                    <p className="text-white-50 small mb-0">10 minutes ago</p>
                  </div>
                  <div className="dropdown-item text-white border-bottom">
                    <p className="mb-1">User <span className="fw-medium">John Doe</span> reported an issue</p>
                    <p className="text-white-50 small mb-0">2 hours ago</p>
                  </div>
                  <div className="dropdown-item text-white">
                    <p className="mb-1">New game zone owner registration</p>
                    <p className="text-white-50 small mb-0">Yesterday</p>
                  </div>
                </div>
                <div className="border-top p-2 text-center">
                  <button className="btn btn-link text-secondary">View all notifications</button>
                </div>
              </div>
            )}
          </div>

          {/* User profile */}
          <div className="position-relative">
            <button onClick={toggleProfileMenu} className="btn btn-link text-white d-flex align-items-center p-1">
              <div
                className="rounded-circle d-flex align-items-center justify-content-center text-white fw-medium"
                style={{
                  width: "32px",
                  height: "32px",
                  background: "linear-gradient(to bottom right, var(--primary), var(--secondary))"
                }}
              >
                {user?.name?.charAt(0)}
              </div>
              <span className="d-none d-md-block ms-2 small fw-medium">{user?.name}</span>
            </button>

            {showProfileMenu && (
              <div className="position-absolute end-0 mt-2 dropdown-menu show fadeIn" style={{ width: "12rem" }}>
                <div className="px-3 py-2 border-bottom">
                  <p className="fw-medium text-white mb-0">{user?.name}</p>
                  <p className="text-white-50 small mb-1">{user?.email}</p>
                  <span className="badge bg-primary bg-opacity-25 text-primary">{user?.role}</span>
                </div>
                <div className="mt-1">
                  <button className="dropdown-item text-white d-flex align-items-center">
                    <User size={16} className="me-2" />
                    <span>Profile</span>
                  </button>
                  <button onClick={handleLogout} className="dropdown-item text-danger d-flex align-items-center">
                    <LogOut size={16} className="me-2" />
                    <span>Logout</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}

export default Header
