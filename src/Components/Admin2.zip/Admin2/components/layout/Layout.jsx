import React, { useEffect, useState } from "react"
import { Outlet, useNavigate } from "react-router-dom"
import { useAuthStore } from "../../store/authStore"
import Header from "./Header"
import Sidebar from "./Sidebar"

const Layout = () => {
  const { isAuthenticated } = useAuthStore()
  const navigate = useNavigate()
  const [sidebarOpen, setSidebarOpen] = useState(true)

  useEffect(() => {
    // if (!isAuthenticated) navigate("/login")

    const handleResize = () => setSidebarOpen(window.innerWidth >= 992)
    handleResize()
    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [isAuthenticated, navigate])

  const toggleSidebar = () => setSidebarOpen(!sidebarOpen)
  const closeSidebar = () => window.innerWidth < 992 && setSidebarOpen(false)

  return (
    <div className="d-flex min-vh-100">
      <Sidebar isOpen={sidebarOpen} closeSidebar={closeSidebar} />
      <div
        className="flex-grow-1 d-flex flex-column min-vh-100 overflow-hidden"
        style={{ marginLeft: sidebarOpen && window.innerWidth >= 992 ? "16rem" : "0" }}
      >
        <Header toggleSidebar={toggleSidebar} />
        <main className="flex-grow-1 overflow-auto p-3 p-md-4">
          <div className="container-fluid">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  )
}

export default Layout
